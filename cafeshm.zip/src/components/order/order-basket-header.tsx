export function OrderBasketHeader() {
  return (
    <div className="flex justify-between items-center my-3 mx-3">
      <h2 className="text-2xl font-semibold">Ваш заказ:</h2>
    </div>
  );
}
