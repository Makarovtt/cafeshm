import { Button } from "@nextui-org/react";
import Link from "next/link";
import { YUKassaBtn } from "./order-yukassa-btn";
import { useEffect } from "react";

export function OrderSubmit({
  isCheckOrder,
  sendOrder,
  funcAddClientIfo,
  isLoading,
  errorText,
  sumOrder,
  selected2,
  checkResultOrder,
  phoneErrors,
}: {
  isCheckOrder: boolean;
  sendOrder: () => void;
  funcAddClientIfo: () => void;
  isLoading: boolean;
  errorText: string;
  sumOrder: number;
  selected2: string | number;
  checkResultOrder: boolean;
  phoneErrors: string;
}) {
  // console.log(!(isCheckOrder && sumOrder >= 1000));
  const scriptCode = `<script>
                        const checkout = new window.YooMoneyCheckoutWidget({
                            confirmation_token: 'live_wA9Ia-xIxCtGbiEFqJSIv_r4FmzYrnB0nl74t4I9flE', 
                            return_url: 'https://cafeshm.ru'
                            error_callback: function(error) {
                              
                            }
                        });

                        checkout.render('payment-form')

                          .then(() => {
                            
                          });
                        </script>`;

  // useEffect(() => {
  //   const script = document.createElement("script");

  //   script.src = "https://yookassa.ru/checkout-widget/v1/checkout-widget.js";
  //   script.async = true;

  //   document.body.appendChild(script);

  //   return () => {
  //     document.body.removeChild(script);
  //   };
  // }, []);
  return (
    <>
      {errorText && (
        <div className="text-red-700 text-lg font-semibold">{errorText}</div>
      )}
      {sumOrder < 1000 && !checkResultOrder && (
        <div className="text-red-700 text-md font-semibold pl-0 ml-0 md:pl-8 md:ml-3 mb-3">
          Сумма заказа должна быть не менее 1000 рублей
        </div>
      )}
      {phoneErrors != "" && !checkResultOrder && (
        <div className="text-red-700 text-md font-semibold pl-0 ml-0 md:pl-8 md:ml-3 mb-3">
          Не указан телефон
        </div>
      )}
      <div
        className="flex justify-start items-start border-l-gray-300 pl-0 ml-0 border-none
                       md:pl-8 md:ml-3 md:border-l"
      >
        <div className="flex w-full flex-col">
          {selected2 === "cash" && (
            <Button
              color="primary"
              isLoading={isLoading}
              size="lg"
              isDisabled={!(isCheckOrder && sumOrder >= 1000)}
              onClick={sendOrder}
            >
              Заказать
            </Button>
          )}
          {selected2 === "online" && (
            <YUKassaBtn
              sumOrder={sumOrder}
              isLoading={isLoading}
              isCheckOrder={isCheckOrder}
              funcAddClientIfo={funcAddClientIfo}
            />
          )}
        </div>
      </div>

      <div className="pl-8 ml-3 mt-3 text-sm">
        * Сумма заказа должна быть не менее 1000 рублей
      </div>
      <div className="pl-8 ml-3 mt-3 text-sm">
        * Заполните все необходимые поля
      </div>
      <div className="pl-8 ml-3 mt-3 text-sm">
        * Подтверждая заказ, Вы соглашаетесь с условиями{" "}
        <Link href="#" className="underline hover:no-underline">
          <strong>политики конфиденциальности</strong>
        </Link>{" "}
        и{" "}
        <Link href="#" className="underline hover:no-underline">
          <strong>правилами продажи</strong>
        </Link>
        .
      </div>

      {/* <div id="payment-form"></div>
      <div dangerouslySetInnerHTML={{ __html: scriptCode }} /> */}
    </>
  );
}
