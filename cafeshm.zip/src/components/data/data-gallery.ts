import Img1 from "@/public/images/gallery/t-img1.jpg";
import Img2 from "@/public/images/gallery/t-img2.jpg";
import Img3 from "@/public/images/gallery/t-img3.jpg";
import Img4 from "@/public/images/gallery/t-img4.jpg";
import Img5 from "@/public/images/gallery/t-img5.jpg";
import Img6 from "@/public/images/gallery/t-img6.jpg";
import Img7 from "@/public/images/gallery/t-img7.jpg";
import Img8 from "@/public/images/gallery/t-img8.jpg";
import Img9 from "@/public/images/gallery/t-img9.jpg";
import Img10 from "@/public/images/gallery/001.jpg";
import Img11 from "@/public/images/gallery/002.jpg";
import Img12 from "@/public/images/gallery/003.jpg";
import Img13 from "@/public/images/gallery/004.jpg";
import Img14 from "@/public/images/gallery/005.jpg";
import Img15 from "@/public/images/gallery/006.jpg";

export const DataGallery = [
  Img1,
  Img2,
  Img3,
  Img4,
  Img5,
  Img6,
  Img7,
  Img8,
  Img9,
  Img10,
  Img11,
  Img12,
  Img13,
  Img14,
  Img15,
];

export const DataGallery2 = [
  "/images/gallery/t-img1.jpg",
  "/images/gallery/t-img2.jpg",
  "/images/gallery/t-img3.jpg",
  "/images/gallery/t-img4.jpg",
  "/images/gallery/t-img5.jpg",
  "/images/gallery/t-img6.jpg",
  "/images/gallery/t-img7.jpg",
  "/images/gallery/t-img8.jpg",
  "/images/gallery/t-img9.jpg",
  "/images/gallery/001.jpg",
  "/images/gallery/002.jpg",
  "/images/gallery/003.jpg",
  "/images/gallery/004.jpg",
  "/images/gallery/005.jpg",
  "/images/gallery/006.jpg",
];
